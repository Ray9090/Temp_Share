﻿using System;
using System.Text;
using TwinCAT.Ads;
using System.Timers;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Windows.Forms;
using System.Linq;

namespace AdsTimeMeasurementConsoleApp
{
    class TraceAdsSymbol
    {
        public bool _connectionStatus;
        private AdsClient _adsclient = new AdsClient();
        private string _netId;
        private int _port;
        private AdsSymbol _adssymbol_output = new AdsSymbol();
        private AdsSymbol _adssymbol_input = new AdsSymbol();

        private AdsSymbol _adssymbol_combo = new AdsSymbol();

        private ConcurrentQueue<Sample> _samples_output = new ConcurrentQueue<Sample>();
        private ConcurrentQueue<Sample> _samples_input = new ConcurrentQueue<Sample>();
        private Sample _sample_output = new Sample();
        private Sample _sample_input = new Sample();
        private int _cntsamples_output, _cntsamples_input;
        private System.Timers.Timer _timer = new System.Timers.Timer();
        public event EventHandler Completed;
        private StringBuilder _stringbuilder_output = new StringBuilder();
        private StringBuilder _stringbuilder_input = new StringBuilder();
        public TraceAdsSymbol() { }
        public TraceAdsSymbol(string netId, int port, AdsSymbol adssymbol_output, AdsSymbol adssymbol_input)
        {
            this._netId = netId;
            this._port = port;
            this._port = port;
            this._adssymbol_output = adssymbol_output;
            this._adssymbol_input = adssymbol_input;
        }
        public StringBuilder stringbuilder_output
        {
            get { return this._stringbuilder_output; }
        }
        public StringBuilder stringbuilder_input
        {
            get { return this._stringbuilder_input; }
        }
        public void Start(double time)
        {
            try
            {
                this._stringbuilder_output.Clear();
                this._stringbuilder_input.Clear();
                Clear(this._samples_output);
                Clear(this._samples_input);
                this._cntsamples_output = 0;
                this._cntsamples_input = 0;

                this._adsclient.Connect(_netId, _port);

                if (this._adsclient.IsConnected)
                {
                    //Console.WriteLine(DateTime.Now.ToString() + ":\t" + "connected to: " + "netId: " + _netId + ", port: " + _port);
                    //this._stringbuilder_input.AppendLine("AMS NetId: " + _netId);
                    //this._stringbuilder_input.AppendLine("AMS Port: " + _port);
                    //this._stringbuilder_input.AppendLine("Ads Variable: " + _adssymbol_input.varname);
                    //this._stringbuilder_input.AppendLine("Type Ads Variable: " + _adssymbol_input.type.Name);
                    //this._stringbuilder_input.AppendLine("Trace settings: " + "AdsTransMode: " + _adssymbol_input.settings.NotificationMode + ", CycleTime: " + _adssymbol_input.settings.CycleTime + ", MaxDelay: " + _adssymbol_input.settings.MaxDelay);
                    //this._stringbuilder_input.AppendLine();
                    this._stringbuilder_input.AppendLine("sample" + ";" + "value" + ";" + "timestamp" );

                    //this._stringbuilder_output.AppendLine("AMS NetId: " + _netId);
                    //this._stringbuilder_output.AppendLine("AMS Port: " + _port);
                    //this._stringbuilder_output.AppendLine("Ads Variable: " + _adssymbol_output.varname);
                    //this._stringbuilder_output.AppendLine("Type Ads Variable: " + _adssymbol_output.type.Name);
                    //this._stringbuilder_output.AppendLine("Trace settings: " + "AdsTransMode: " + _adssymbol_output.settings.NotificationMode + ", CycleTime: " + _adssymbol_output.settings.CycleTime + ", MaxDelay: " + _adssymbol_output.settings.MaxDelay);
                    //this._stringbuilder_output.AppendLine();
                    this._stringbuilder_output.AppendLine("sample" + ";" + "value" + ";" + "timestamp" );



                    //this._stringbuilder_output.Append(this._samples_input);

                    AddAdsNotifications();
                    //Console.WriteLine(DateTime.Now.ToString() + ":\t" + "add variable to notification: " + _adssymbol_output.varname);
                    //Console.WriteLine(DateTime.Now.ToString() + ":\t" + "add variable to notification: " + _adssymbol_input.varname);
                    SetTimer(time);
                    //Console.WriteLine(DateTime.Now.ToString() + ":\t" + "start timer and collect samples");
                }
                _connectionStatus = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(DateTime.Now.ToString() + ":\t" + "error: " + ex.Message);
                _connectionStatus = false;
            }
        }
        public void Clear<T>(ConcurrentQueue<T> queue)
        {
            T item;
            while (queue.TryDequeue(out item))
            {
            }
        }

        private void SetTimer(double time)
        {
            try
            {
                this._timer.Interval = time;
                this._timer.AutoReset = false;
                this._timer.Enabled = true;
                this._timer.Elapsed += TimeElapsedEvent;
            }
            catch (Exception ex)
            {
                MessageBox.Show(DateTime.Now.ToString() + ":\t" + "error: " + ex.Message);
            }
        }

        private void AddAdsNotifications()
        {
            try
            {
                this._adsclient.AdsNotificationEx += adsclient_AdsNotification_output; 
                this._adsclient.AdsNotificationEx += adsclient_AdsNotification_input;
                this._adssymbol_output.handle = _adsclient.AddDeviceNotificationEx(_adssymbol_output.varname, _adssymbol_output.settings, null, _adssymbol_output.type);
                this._adssymbol_input.handle = _adsclient.AddDeviceNotificationEx(_adssymbol_input.varname, _adssymbol_input.settings, null, _adssymbol_input.type);


                //this._adsclient.AdsNotificationEx += adsclient_AdsNotification_input;
                //this._adssymbol_combo.handle = _adsclient.AddDeviceNotificationEx(_adssymbol_output.varname, _adssymbol_output.settings, null, _adssymbol_output.type);
            }
            catch (Exception ex)
            {
                MessageBox.Show(DateTime.Now.ToString() + ":\t" + "error: " + ex.Message);
            }
        }
        private void adsclient_AdsNotification_output(object sender, AdsNotificationExEventArgs e)
        {
            try
            {
                if (e.Handle == this._adssymbol_output.handle)
                {
                    if((bool)e.Value)
                    {
                        this._samples_output.Enqueue(new Sample(e.Value, e.TimeStamp.TimeOfDay.Ticks));
                        Parallel.Invoke(SamplesToString_Output);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(DateTime.Now.ToString() + ":\t" + "error: " + ex.Message);
            }
        }
        private void adsclient_AdsNotification_input(object sender, AdsNotificationExEventArgs e)
        {
            try
            {
                if (e.Handle == this._adssymbol_input.handle)
                {
                    if((bool)e.Value)
                    {
                        this._samples_input.Enqueue(new Sample(e.Value, e.TimeStamp.TimeOfDay.Ticks));
                        Parallel.Invoke(SamplesToString_input);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(DateTime.Now.ToString() + ":\t" + "error: " + ex.Message);
            }
        }


        public void SamplesToString_Output()
        {
            try
            {
                while (_samples_output.TryDequeue(out _sample_output))
                {
                    this._stringbuilder_output.AppendLine(_cntsamples_output + ";" + _sample_output.value + ";" + _sample_output.timestampTicks);
                    this._cntsamples_output++;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.Now.ToString() + ":\t" + "error: " + ex.Message);
            }
        }
        public void SamplesToString_input()
        {
            try
            {
                while (_samples_input.TryDequeue(out _sample_input))
                {
                    this._stringbuilder_input.AppendLine(_cntsamples_input + ";" + _sample_input.value + ";" + _sample_input.timestampTicks);
                    this._cntsamples_input++;
                
                }
            }
            catch (Exception ex)
            {
                //Console.WriteLine(DateTime.Now.ToString() + ":\t" + "error: " + ex.Message);
            }
        }
    
        private void TimeElapsedEvent(object sender, ElapsedEventArgs e)
        {
            try
            {
                //Console.WriteLine(DateTime.Now.ToString() + ":\t" + "collecting samples completed");
                this._timer.Elapsed -= TimeElapsedEvent;
                this._adsclient.AdsNotificationEx -= adsclient_AdsNotification_output;
                this._adsclient.AdsNotificationEx -= adsclient_AdsNotification_input;
                this._adsclient.DeleteDeviceNotification(_adssymbol_output.handle);
                this._adsclient.DeleteDeviceNotification(_adssymbol_input.handle);
                Completed?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                //Console.WriteLine(DateTime.Now.ToString() + ":\t" + "error: " + ex.Message);
            }
        }
        public void Dispose()
        {
            this._timer.Dispose();
            this._adsclient.Dispose();
        }
    }

    public class AdsSymbol
    {
        public string varname;
        public Type type;
        public uint handle;
        public NotificationSettings settings;
        public AdsSymbol() { }
        public AdsSymbol(string varname, Type type, uint handle, NotificationSettings settings)
        {
            this.varname = varname;
            this.type = type;
            this.handle = handle;
            this.settings = settings;
        }
    }
    public class Sample
    {
        public object value;
        public long timestampTicks;
        public Sample() { }
        public Sample(object value, long timestampTicks)
        {
            this.value = value;
            this.timestampTicks = timestampTicks;
        }
    }
}
