﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General information about this assembly is provided by the following set of
// set of attributes. Change the values of these attributes to change the information // associated with the assembly,
// related to the assembly.
[assembly: AssemblyTitle("TwinCAT")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("TwinCAT")]
[assembly: AssemblyCopyright("Copyright ©  2022")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting False for the ComVisible parameter makes the types in this assembly invisible
// for COM components. If you want to refer to a type in this assembly through
// COM, you should set the ComVisible attribute to TRUE for that type.
[assembly: ComVisible(false)]

// the following GUID is used to identify the type library, if this project will be visible to COM
[assembly: Guid("1e0d7d31-5536-44bc-b13f-2865f25bb091")]

// The build version information consists of the following four values:
//
// Main version number
// Additional version number
// Assembly number
// Revision
//
// You can set all values or accept the default build and revision numbers 
// using "*" as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
