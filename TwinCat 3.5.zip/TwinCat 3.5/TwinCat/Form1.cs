﻿using System;
using System.Data;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using TwinCAT.Ads;
using AdsTimeMeasurementConsoleApp;
using Csv;

namespace TwinCAT
{
    public partial class Form1 : Form
    {
        TextWriter _writer = null;
        public Form1()
        {
            InitializeComponent();
        }

        static TraceAdsSymbol trace;

        string path_output = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString(), "output.csv");
        string path_input = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString(), "input.csv");

        private void bConnect_Click(object sender, EventArgs e)
        {
            if (bConnect.Text == "Connect")
            {
                double time;
                if (cbTimer.Text == "seconds")
                    time = double.Parse(tbTimer.Text) * 1000;  // for recoding in seconds
                else
                    time = double.Parse(tbTimer.Text) * 60 * 1000;  // for records in minutes

                try
                {
                    AdsSymbol adssymbol_output = new AdsSymbol(comboBox2.Text, typeof(bool), 0, new NotificationSettings(AdsTransMode.OnChange, 0, 0));
                    AdsSymbol adssymbol_input = new AdsSymbol(comboBox3.Text, typeof(bool), 0, new NotificationSettings(AdsTransMode.OnChange, 0, 0));
                    trace = new TraceAdsSymbol(comboBox1.Text, Int32.Parse(tbPort.Text), adssymbol_output, adssymbol_input);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(DateTime.Now.ToString() + ":\t" + "error: " + ex.Message);
                    return;
                }

                trace.Start(time);

                trace.Completed += traceCompleted;

                if(trace._connectionStatus)
                {
                    bConnect.Text = "Disconnect";
                    tbPort.ReadOnly = true;
                    tbTimer.ReadOnly = true;
                    cbTimer.Enabled = false;
                    bConnect.BackColor = Color.FromArgb(192, 255, 192);
                }
                return;
            }

            if(bConnect.Text == "Disconnect")
            {
                bConnect.Text = "Connect";
                bConnect.BackColor = Button.DefaultBackColor;
                tbPort.ReadOnly = false;
                tbTimer.ReadOnly = false;
                cbTimer.Enabled = true;
                trace.Dispose();
            }
        }
        void traceCompleted(object sender, EventArgs e)
        {
            StringBuilder stringbuilder_output = new StringBuilder();
            StringBuilder stringbuilder_input = new StringBuilder();

            stringbuilder_output = trace.stringbuilder_output;
            File.WriteAllText(path_output, stringbuilder_output.ToString());

            stringbuilder_input = trace.stringbuilder_input;
            File.WriteAllText(path_input, stringbuilder_input.ToString());

            // try 1
            //File.WriteAllText(path_input, stringbuilder_input.ToString() + stringbuilder_output);

            //try 2
            //File.WriteAllText(path_input, stringbuilder_output.ToString());

            //try 3
            //using(System.IO.StreamWriter file = new System.IO.StreamWriter (path_output))
            //{
            //file.WriteLine(stringbuilder_output.ToString());
            //file.WriteLine(stringbuilder_input.ToString());
            //}

            //try 4
            //File.WriteAllText(path_output, stringbuilder_input.ToString() + Environment.NewLine + stringbuilder_output.ToString() + Environment.NewLine);

            //try 5
            //StringBuilder stringbuilder_combo = new StringBuilder();
            //stringbuilder_combo.Append(stringbuilder_output);
            //stringbuilder_combo.Append(stringbuilder_input);
            //File.WriteAllText(path_input, stringbuilder_combo.ToString());


            this.Invoke(new Action(() =>
            {
                bConnect.BackColor = Button.DefaultBackColor;
                bConnect.Text = "Connect";
                bConnect.BackColor = Button.DefaultBackColor;
                tbPort.ReadOnly = false;
                tbTimer.ReadOnly = false;
                cbTimer.Enabled = true;

                //combine the two separate csv file into one and do the calculation 
                //finalResult();
                txtConsole.Text = "Well done. Check result.csv file in desktop.";
                //MessageBox.Show(DateTime.Now.ToString() + ":\t" + "Well done. Check result.csv file in desktop."); // this create separate message box to display
            }));

        }

        private void tbTimer_Leave(object sender, EventArgs e)
        {
            if (double.Parse(tbTimer.Text) > 60)
            {
                tbTimer.Text = "10";
                //Console.WriteLine(DateTime.Now.ToString() + ":\t" + "Value must be more than 0 and less than 60.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        //private void finalResult()
        //{
        //    int diffInOut = 0;          //thats if Input value was first
        //    int diff2 = 0;              //thats if Output value is last
        //    int countValues = 0;
        //    long sum = 0;

        //    string result = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString(), "result.csv");
            
        //    if (File.Exists(result)) 
        //        File.Delete(result);

        //    var lines_input = File.ReadAllLines(path_input);
        //    var lines_output = File.ReadAllLines(path_output);

        //    var values_out = lines_input[8].Split(';');
        //    var values_in = lines_output[8].Split(';');

        //    List<string> tmp = new List<string>(); 
        //    List<string> tmp2 = new List<string>();

        //    for (int current_line = 0; current_line < 5; current_line++)
        //    {
        //        tmp.Add(string.Concat(lines_output[current_line] + new string(';', 8) + lines_input[current_line]));
        //    }

        //    tmp.Add("");
        //    tmp.Add(string.Concat(lines_output[6] + new string(';', 6) + lines_input[6]) + new string(';', 6) + "diff");

        //    File.AppendAllLines(result, tmp);

        //    if (long.Parse(values_out[2]) < long.Parse(values_in[2]))
        //        diffInOut = 1;

        //    if(lines_input.Length != lines_output.Length)
        //        diff2 = 1;

        //    for (int current_line = 8; current_line < lines_output.Length - diff2; current_line++)
        //    {
        //        var values_input = lines_input[current_line + diffInOut].Split(';');
        //        var values_output = lines_output[current_line].Split(';');

        //        long diff = long.Parse(values_input[2]) - long.Parse(values_output[2]);

        //        countValues++;
        //        sum += diff;

        //        if (diffInOut == 1)
        //            tmp2.Add(string.Concat(lines_output[current_line] + new string(';', 6) +
        //            string.Concat((Int32.Parse(values_input[0]) - 1).ToString() + ';' + values_input[1] + ';' + values_input[2]) + new string(';', 6) + diff));
        //        else
        //            tmp2.Add(string.Concat(lines_output[current_line] + new string(';', 6) + lines_input[current_line]) + new string(';', 6) + diff);  
        //    }

        //    File.AppendAllLines(result, tmp2);

        //    tbUD01.Text = TimeSpan.FromTicks(sum / countValues).TotalMilliseconds.ToString();

        //    File.Delete(path_input);
        //    File.Delete(path_output);
        //}
    }
}
